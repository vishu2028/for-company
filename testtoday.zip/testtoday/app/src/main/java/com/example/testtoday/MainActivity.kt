package com.example.testtoday

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.testtoday.Interfaces.Onclck
import com.example.testtoday.UI.BiodataActivity2
import com.example.testtoday.UserViewModle.MyAdapter
import com.example.testtoday.UserViewModle.UserViewModel
import com.example.testtoday.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), Onclck {
    private lateinit var binding: ActivityMainBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MyAdapter
    private val userViewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = MyAdapter(ArrayList(), this)
        recyclerView = binding.recyclerview
        recyclerView.adapter = adapter

        userViewModel.fethUsers()
        searchview()

        userViewModel.users.observe(this, { users ->
            adapter.updateUsers(users)
        })

        userViewModel.loading.observe(this, { loading ->
           
        })


        userViewModel.filteredusers.observe(this, { filteredUsers ->
            adapter.updateUsers(filteredUsers)
        })
    }



    override fun nextclick(position: Int) {
        val clickedUser = adapter.userlist[position]
        Toast.makeText(this, "Clicked user: ${clickedUser}", Toast.LENGTH_SHORT).show()
        if (clickedUser != null){
            val intent = Intent(this,BiodataActivity2::class.java)
                .apply {
                    putExtra("email",clickedUser.email)
                    putExtra("username",clickedUser.username)
                    putExtra("phone",clickedUser.phone)
                    putExtra("add_city",clickedUser.address.city)
                    putExtra("add_zip",clickedUser.address.zipcode)
                    putExtra("add_street",clickedUser.address.street)
                    putExtra("add_sutite",clickedUser.address.suite)

                }
            startActivity(intent)
        }









    }

    private fun searchview(){
        binding.searchview.setOnQueryTextListener(object  : androidx.appcompat.widget.SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                userViewModel.filterUsers(query?:"")
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                userViewModel.filterUsers(newText ?:"")
                return true
            }

        })
    }


}

