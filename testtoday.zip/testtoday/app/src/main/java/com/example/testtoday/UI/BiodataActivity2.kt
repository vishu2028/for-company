package com.example.testtoday.UI

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.testtoday.R
import com.example.testtoday.databinding.ActivityBiodata2Binding

class BiodataActivity2 : AppCompatActivity() {
    private lateinit var binding: ActivityBiodata2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       binding = ActivityBiodata2Binding.inflate(layoutInflater)
        setContentView(binding.root)


        val username = "username : " +intent.getStringExtra("username")
        val phone  = "Phone : " + intent.getStringExtra("phone")
            val email = "Email : " + intent.getStringExtra("email")
                val add_city ="City :" + intent.getStringExtra("add_city")
                    val add_suite = "Suite : " + intent.getStringExtra("add_sutite")
               val add_street = "Street :"+ intent.getStringExtra("add_street")
        val add_zip = "Zipcode :"+ intent.getStringExtra("add_zip")



        binding.txtEmail.text = email
        binding.txtPhone.text = phone
        binding.txtUsername.text = username
        binding.txtAddress.text = "Address: $add_city \n $add_suite \n $add_zip \n $add_street"







    }
}