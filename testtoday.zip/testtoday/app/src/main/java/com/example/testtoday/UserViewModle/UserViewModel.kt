package com.example.testtoday.UserViewModle

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.testtoday.Modles.dataclasses.UserDitles
import com.example.testtoday.Modles.dataclasses.UserDitlesItem
import com.example.testtoday.Repositor.UserRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserViewModel:ViewModel() {
    private val repository = UserRepository()
    private  val _users = MutableLiveData<List<UserDitlesItem>>()
    val users:LiveData<List<UserDitlesItem>> get() = _users
    private  val _filteredUsers =MutableLiveData<List<UserDitlesItem>>()
    val filteredusers:LiveData<List<UserDitlesItem>> get() =  _filteredUsers
   private val _loading = MutableLiveData<Boolean>()
    val loading:LiveData<Boolean> get() = _loading

    fun fethUsers(){
        repository.getusers().enqueue(object : Callback<UserDitles> {
            override fun onResponse(call: Call<UserDitles>, response: Response<UserDitles>) {
                _loading.value = false
                if (response.isSuccessful) {
                    _users.value = response.body()
                    _filteredUsers.value = response.body()
                }
            }

            override fun onFailure(call: Call<UserDitles>, t: Throwable) {
                _loading.value = false
            }
        })
    }

    fun filterUsers(query: String) {
        _filteredUsers.value = if (query.isEmpty()) {
            _users.value
        } else {
            _users.value?.filter { it.username.contains(query, true) }
        }
    }
}

