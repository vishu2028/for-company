package com.example.testtoday.Repositor


import com.example.testtoday.Modles.dataclasses.UserDitles
import com.example.testtoday.api.Apifatch
import com.example.testtoday.api.RetrofitRefrence
import retrofit2.Call

class UserRepository {
    private  val apifatch:Apifatch = RetrofitRefrence.serviceBuilder(Apifatch::class.java)

    fun getusers(): Call<UserDitles> {
        return apifatch.fethdata()
    }
}