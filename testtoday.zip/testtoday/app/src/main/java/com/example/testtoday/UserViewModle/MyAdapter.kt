package com.example.testtoday.UserViewModle

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.testtoday.Interfaces.Onclck
import com.example.testtoday.Modles.dataclasses.UserDitlesItem
import com.example.testtoday.R

class MyAdapter(var userlist: ArrayList<UserDitlesItem>, val onclck: Onclck):RecyclerView.Adapter<MyAdapter.MyDataholder>() {

    class MyDataholder(item: View,onclck: Onclck):RecyclerView.ViewHolder(item){

    val username  = item.findViewById<TextView>(R.id.txt_username)
        val email = item.findViewById<TextView>(R.id.txt_email)
        val layoutshow = item.findViewById<ConstraintLayout>(R.id.layout_row)

        init {
       layoutshow.setOnClickListener {
          onclck.nextclick(adapterPosition)
       }
        }

        fun onbind(item: UserDitlesItem){
            username.text = item.username
            email.text = item.email
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyDataholder {
       val  item = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return   MyDataholder(item,onclck)
    }

    override fun getItemCount(): Int {
        return  userlist.size
    }

    override fun onBindViewHolder(holder: MyDataholder, position: Int) {
        val current = userlist[position]
        holder.onbind(current)

    }
    fun updateUsers(users: List<UserDitlesItem>) {
        userlist = users as ArrayList<UserDitlesItem>
        notifyDataSetChanged()
    }
}