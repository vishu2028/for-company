package com.example.testtoday.Interfaces

interface Onclck {
    fun  nextclick(position:Int)

}