package com.example.testtoday.Modles.dataclasses

class UserDitles : ArrayList<UserDitlesItem>()