package com.example.testtoday.Modles.dataclasses

data class Geo(
    val lat: String,
    val lng: String
)