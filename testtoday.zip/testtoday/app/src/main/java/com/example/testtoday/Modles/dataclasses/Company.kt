package com.example.testtoday.Modles.dataclasses

data class Company(
    val bs: String,
    val catchPhrase: String,
    val name: String
)