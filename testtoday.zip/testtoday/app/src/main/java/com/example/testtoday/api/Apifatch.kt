package com.example.testtoday.api


import com.example.testtoday.Modles.dataclasses.UserDitles
import retrofit2.Call
import retrofit2.http.GET

interface Apifatch {

   @GET("users")
     fun fethdata():Call<UserDitles>
}